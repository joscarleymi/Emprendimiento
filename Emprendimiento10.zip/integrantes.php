<head>
  <h3><a href="index.php"> regresar</a></h3>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>Emprendimiento</title></title>
  <link href="css/styles2.css" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <h3><center>Intregrantes</center></h3>

    <table id="tabla">
<tr>
<td>nombre</td>
<td>correo</td>  
</tr>
  
<tr>
<td>Carol Juliana Martinez Diaz</td> 
<td>
  <?php
$email = "fya.caroljulianamartinezdiaz@gmail.com";
// Dirección de correo electrónico

// Imprime el enlace de correo electrónico en HTML
echo "<a href='mailto:$email'>$email</a>";
?>
</td> 
</tr>
  <tr>
<td>Alexis De Jesus Martinez</td> 
<td>
  <?php
$email = "alexis1708maz@gmail.com";
// Dirección de correo electrónico

// Imprime el enlace de correo electrónico en HTML
echo "<a href='mailto:$email'>$email</a>";
?>
</td>
</tr>
  
  <tr>
<td>Joscarleymi Leon</td> 
  <td>
  <?php
$email = "leonjoscarleymidaniela@gmail.com";
// Dirección de correo electrónico

// Imprime el enlace de correo electrónico en HTML
echo "<a href='mailto:$email'>$email</a>";
?>
</td> 
</tr>
  <tr>
<td>Ruben Dario Tapias Posada</td> 
  <td>
  <?php
$email = "rubenposada792@gmail.com";
// Dirección de correo electrónico

// Imprime el enlace de correo electrónico en HTML
echo "<a href='mailto:$email'>$email</a>";
?>
</td>  
</tr>    
  
</table>
</body>
</html>

  