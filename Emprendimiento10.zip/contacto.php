<html>
  <head>
    <title>Contactos</title>
    <h3><a href="index.php"> regresar</a></h3>
    <link href="css/styles2.css" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <h3><center>PLATAFORMAS</center></h3>
    
</body>
</html>
<table id="tabla">
  
<tr>
<td>
  <?php
$email = "fruitdesserts4@gmail.com";
// Dirección de correo electrónico

// Imprime el enlace de correo electrónico en HTML
echo "<a href='mailto:$email'><img src='img/gmail.png' width='20%' height='20%'></a>";
?>
</td>   
<td>
  <?php
$nombreDeUsuarioFacebook = "FRUIT DESSERTS"; // Reemplaza esto con tu nombre de usuario de Facebook
$textoDelEnlace = "FRUIT DESSERTS"; // Texto que se mostrará para el enlace

$enlace = "https://www.facebook.com/{FRUIT DESSERTS}"; // URL a tu perfil de Facebook

echo "<a href='https://web.facebook.com/profile.php?id=61551359346309' target='_blank'><img src='img/R .jpg' width='20%' height='20%''></a>";
?>

</td> 
<td><img src="img/descargar.jpg" width="20%" height="20%"></td>   
</tr>  
  
</table>
</body>
</html>

 