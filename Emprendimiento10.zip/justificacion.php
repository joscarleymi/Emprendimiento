<html>
  <head>
    <title>Propuesta:Titulo</title>
    <link href="estilo.nix" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <h3><center>Justificacion</center></h3>
    <li>Es importante porque ayudamos a las personas a llevar una vida saludable atraves de su alimentación y nuestros productos.</li>
  </body>
</html>