<head>
  <link href="css/styles2.css" rel="stylesheet" type="text/css" />
</head>
<body>
  <center>
  <h2>Total de visitas en la presentacion del proyecto=
  174</h2>
  <h2> Promedio
  4.96</h2>
 
  
      <h2>PORCENTAJE</h2>
      <h3><li>95.40% dieron 5</li></h3>
     <h3><li>4.59% dieron 4</li></h3>
        <h3><li>0% dieron 3</li><h3>
           <h3><li>0% dieron 2</li></h3>
              <h3>0% dieron 1</li></h3>
   </center>
  
 
</body>