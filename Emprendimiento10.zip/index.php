<html>
  <head>
    
    <title>Propuesta:Postres a bases de frutas</title>
    <link href="css/styles2.css" rel="stylesheet" type="text/css" />
    </head>
 <table id="tabla">
   <body id="page-top">
        <!-- Navigation-->
        <?  include 'menu.php' ?>
        <!-- Header-->
      <center>
        <header class="masthead d-flex align-items-center">
            <div class="container px-4 px-lg-5 text-center">
             
            <h1><center>FRUIT DESSERTS</center></h1>
  <h1><center>GRADO:10°</center></h1>
  <h1><center>IE Fe y Alegria Aures</center></h1>    
  <h1><center>MEDELLIN-COLOMBIA</center></h1>
  <h1><center>2023 </center></h1>
  <script src="script.js"></script>
 </table>
</form>
<center><img src="img/qr-code.png" width="20%" height="30%"></center>              <center>
                <h1 class="mb-1">FRUIT DESSERTS</h1>
                <h2 class="mb-5"><em>LOGOSIMBOLO:Frutas en armonía,postres que alegría</em></h2>
              <h2 class="mb-5"><em>LEMA:Sabores naturales convertidos en exquisitas tentaciones, <br>deleitando tus sentidos con postres,para endulzar cada momento de tu vida</br></em></h2>
     <h2 class="mb-5"><em>LOGO</em></h2>         
    <img src="img/logo.jpeg" width="20%" height="30%">
<h2><em>Bienvenido </em></h2>
               
            </div>
        </section>
        <!-- Proyecto -->
        <?include 'proyecto.php'?>
        <!-- Call to Action-->
        <section class="content-section bg-primary text-white">
            <div class="container px-4 px-lg-5 text-center">
                <h2 class="mb-4"></h2>
                <a class="btn btn-xl btn-light me-4" href="#!">Click Me!</a>
                <a class="btn btn-xl btn-dark" href="#!">Look at Me!</a>
            </div>
        </section>
        <!-- contacto-->
        <? include 'contacto.php'?>
        <!-- Footer-->
        <footer class="footer text-center">
            <div class="container px-4 px-lg-5">
                <ul class="list-inline mb-5">
                    <li class="list-inline-item">
                        <a class="social-link rounded-circle text-white mr-3" href="#!"><i class="icon-social-facebook"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a class="social-link rounded-circle text-white mr-3" href="#!"><i class="icon-social-twitter"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a class="social-link rounded-circle text-white" href="#!"><i class="icon-social-github"></i></a>
                    </li>
                </ul>
                <p class="text-muted small mb-0">Copyright &copy; Your Website 2023</p>
            </div>
        </footer>
        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top"><i class="fas fa-angle-up"></i></a>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
          </center>
              </center>
    </body>
  </body>
</html>
