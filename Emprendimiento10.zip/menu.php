
<a class="menu-toggle rounded" href="#"><i class="fas fa-bars"></i></a>
        <nav id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-nav-item"><a href="#page-top">Home</a></li>
                <li class="sidebar-nav-item"><a href="acerca.php">Acerca</a></li>
                <li class="sidebar-nav-item"><a href="productos.php">Productos</a></li>
                <li class="sidebar-nav-item"><a href="proyecto.php">Proyecto</a></li>
                <li class="sidebar-nav-item"><a href="contacto.php">Contacto</a></li>
              <li class="sidebar-nav-item"><a href="integrantes.php">integrantes</a></li>
              <li class="sidebar-nav-item"><a href="Calificacion.php">Calificacion</a></li>
            </ul>
        </nav>
