 <head>
   <h3><a href="index.php"> regresar</a></h3>
    <title>Productos</title>
   <link href="css/styles.css" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <br>
    <h3><li>Dulce de mango</li></h3>
    <img src="img/jalea.jpg" width="50%" height="50%">
  </br>
    <br>
      <h3><li>Dulce de fresa</li></h3>
    <img src="img/fresa.jpg" width="50%" height="50%">
  </br>
    <br>
      <h3><li>Fresas con crema</li></h3>
    <img src="img/fresaconcrema.jpg" width="50%" height="50%">
  </br>
    <br>
      <h3><li>Dulce de maracuya</li></h3>
    <img src="img/compota.jpg" width="50%" height="50%">
    </br>
    <br>
       <h3><li>Dulce de piña</li></h3>
    <img src="img/piña.jpg" width="50%" height="50%">
  </br>
  </body>
</html>