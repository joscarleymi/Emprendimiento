<php>
  <head>
    <center>
    <h3><center><a href="index.php"> regresar</a></center></h3>
    <title>Propuesta:Postres a bases de frutas</title>
    <link href="css/styles2.css" rel="stylesheet" type="text/css" />
    </head>
  <div class="col-lg-6">
<a class="portfolio-item" href="#!">
<div class="caption">
<div class="caption-content">
<div class="h2"><h2> Filosofia:</h2></div>
<p class="mb-0"><h3>Etica empresarial al momentode fabricar nuestros productos,<br>estos son accesibles a todo tipo de personas que deban ser de calidad y con precios justos</h3></p>
</div>
</div>
</div>

  <div class="col-lg-6">
<a class="portfolio-item" href="#!">
<div class="caption">
<div class="caption-content">
<div class="h2"><h2>Misión:</h2></div>
<p class="mb-0"><h3>Nuestro objetivo en la sociedad atravez de nuestros proyecto es ofrecer productos saludables y rentables.</h3></p>
</div>
</div>
</div>
  
 <div class="col-lg-6">
<a class="portfolio-item" href="#!">
<div class="caption">
<div class="caption-content">
<div class="h2"><h2>visión:</h2></div>
<p class="mb-0"><h3>Llegar a generar ingresos a traves de nuestros productos de manera saludable al consumidor.</h3></p>
</div>
</div>
</div>
                
  <div class="col-lg-6">
  <a class="portfolio-item" href="#!">
  <div class="caption">
  <div class="caption-content">
  <div class="h2"><h2>Justificación</h2></div>
  <p class="mb-0"><h3>Es importante porque ayudamos a las personas a llevar una vida saludable atraves de su alimentación y nuestros productos.</h3> </p>
</div>
</div>
</a>
</div>
  
<div class="col-lg-6">
<a class="portfolio-item" href="#!">
<div class="caption">
<div class="caption-content">
<div class="h2"><h2>Alcance del Sistema</h2></div>
<p class="mb-0"><h3>El sistema va a permitir:
<ul>
<li><br>Accion 1:Interacción con Usuarios.</br></li>
<li><br>Accion 2:Colaboración en Línea.</br></li>
<li><br>Accion 3:comunicación constante.</br></li>
</ul>  
  </h3>
</p>
</div>
</div>
</a>
</div>
                    
<div class="col-lg-6">
<a class="portfolio-item" href="#!">
<div class="caption">
<div class="caption-content">
<div class="h2"><h2>Objetivo General:</h2></div>
<p class="mb-0"><h3>Nuestro objetivo es crear y desarrollar un exitoso emprendimiento centrado en la producción de postres a base de frutas.<br> Queremos ofrecer opciones deliciosas y saludables que inspiren a las personas a adoptar una alimentación más equilibrada y consciente.<br> Esto se logrará a través de recetas innovadoras, ingredientes frescos de alta calidad y la promoción de hábitos alimenticios saludables</br>.</p></h3>
</div>
</div>
</div>
  
<div class="col-lg-6">
<a class="portfolio-item" href="#!">
<div class="caption">
<div class="caption-content">
<div class="h2"><h2>Objetivos especifico:</h2></div>
<p class="mb-0">
  <table>
    <tr>
<td>Objetivo 1:Innovar</td>
    </tr>
    <tr>
<td>Objetivo 2:Realizar Productos de buena calidad y accesible al consumidos</td>  
    </tr>
    <tr>
<td>Objetivo 3:Mejorar conservando los valores de nuestro emprendimiento</td>  
      </tr>
    </table>
</p>
</div>
</div>
</a>
</div>
</section>
</center>